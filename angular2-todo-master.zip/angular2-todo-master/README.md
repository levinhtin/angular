# Angular 2 Todo App

This repo is a part of the tutorial published on [HTMLxprs](http://www.htmlxprs.com/post/54/creating-a-super-simple-todo-app-using-angular-2-tutorial), which explains the creation of a simple Todo app using Angular 2.
