System.register([], function($__export) {
  "use strict";
  var OnChange;
  return {
    setters: [],
    execute: function() {
      OnChange = $__export("OnChange", (function() {
        var OnChange = function OnChange() {};
        return ($traceurRuntime.createClass)(OnChange, {onChange: function(changes) {
            throw "OnChange.onChange is not implemented";
          }}, {});
      }()));
    }
  };
});

//# sourceMappingURL=src/core/compiler/interfaces.map

//# sourceMappingURL=../../../src/core/compiler/interfaces.js.map