System.register(["angular2/src/facade/lang"], function($__export) {
  "use strict";
  var global,
      Math,
      NaN;
  return {
    setters: [function($__m) {
      global = $__m.global;
    }],
    execute: function() {
      Math = $__export("Math", global.Math);
      NaN = $__export("NaN", global.NaN);
    }
  };
});

//# sourceMappingURL=src/facade/math.map

//# sourceMappingURL=../../src/facade/math.js.map